LP_DB - Proyek aplikasi Android

Isi:
- Nama aplikasi: LP_DB
- HTML LP DB Takdut versi musik mencoba otomatis setelah 2 detik disimpan lokal di app/src/main/assets/index.html
- WebView mengaktifkan JavaScript dan mengizinkan pemutaran media tanpa gesture (tetap bergantung versi Android/WebView)
- Workflow GitHub Actions untuk membangun APK otomatis.

CARA MEMBUAT APK TANPA ANDROID STUDIO (PAKAI GITHUB)
1. Ekstrak ZIP ini di HP/komputer.
2. Masuk ke GitHub dan buat repository baru bernama LP_DB. Pilih Private atau Public sesuai keinginan; jangan centang pembuatan README tambahan.
3. Unggah seluruh ISI folder LP_DB_Android ke repository (termasuk folder tersembunyi .github/workflows). Cara termudah di komputer: git init, git add ., git commit -m "LP_DB app", lalu sambungkan repository dan push ke branch main. Di browser GitHub, pastikan folder .github/workflows/build-apk.yml ikut terunggah.
4. Buka tab Actions pada repository. Pilih workflow "Build LP_DB APK" lalu tekan Run workflow. Jika workflow berjalan otomatis setelah push, tunggu sampai selesai.
5. Buka hasil run yang hijau/berhasil, cari bagian Artifacts, lalu unduh "LP_DB-APK".
6. Ekstrak ZIP artifact yang diunduh. Di dalamnya ada app-debug.apk. Buka file APK di HP Android dan izinkan pemasangan dari sumber tersebut jika diminta.

CATATAN PENTING
- APK yang dihasilkan adalah debug APK untuk instalasi langsung, bukan rilis Play Store.
- Jangan mengunggah password, token, atau kunci rahasia ke repository.
- Autoplay musik tetap dapat dibatasi oleh versi Android/WebView.

CARA ALTERNATIF DENGAN ANDROID STUDIO
1. Buka folder LP_DB_Android sebagai proyek.
2. Pastikan Android SDK Platform 35 dan Java 17 tersedia.
3. Jalankan Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK biasanya ada di app/build/outputs/apk/debug/app-debug.apk.
