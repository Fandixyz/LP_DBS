LP_DB Android — versi menu ikon sederhana

Menu utama memudahkan pengguna HP: Data Diri, Kegiatan, Shift 1, Shift 2, Unduh JPG, Kirim, dan Cetak. Isi form dan fungsi laporan asli dipertahankan. Menu ikon disembunyikan saat cetak dan tidak menjadi bagian dari JPG laporan.

Cara build: unzip folder ini, lalu jalankan gradle assembleDebug dari folder LP_DB_Android, atau gunakan workflow GitHub Actions yang sudah tersedia.
