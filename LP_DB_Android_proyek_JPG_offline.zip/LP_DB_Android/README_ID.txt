PROYEK ANDROID LP_DB — JPG OFFLINE

Perbaikan:
- index.html memuat html2canvas dari assets/js/html2canvas.min.js, bukan CDN saat aplikasi berjalan.
- Workflow GitHub Actions mengunduh pustaka saat proses build, lalu memasukkannya ke APK.
- Setelah pustaka dimasukkan saat build, fitur JPG tidak membutuhkan internet untuk memuat html2canvas.
- Tombol Cetak dan Kirim Telegram tidak sengaja dihapus/diubah oleh perbaikan ini. Cetak dan integrasi Telegram tetap perlu diuji pada APK hasil build; Telegram memerlukan internet untuk mengirim.

MEMBANGUN APK:
1. Ekstrak folder LP_DB_Android.
2. Unggah seluruh isi proyek ke repository GitHub.
3. Buka tab Actions dan jalankan workflow "Build LP_DB APK" (Run workflow).
4. Unduh artifact LP_DB-APK dari hasil workflow.

Catatan: proses build memerlukan internet untuk mengunduh html2canvas. Internet tidak diperlukan untuk memuat pustaka JPG ketika aplikasi sudah terpasang. Jika build dilakukan secara lokal, unduh html2canvas 1.4.1 ke app/src/main/assets/js/html2canvas.min.js sebelum menjalankan Gradle.
